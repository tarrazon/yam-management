import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Clock, CheckCircle, XCircle, AlertCircle, Filter, ShoppingBag, ChevronRight, Mail, MailCheck } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

export default function SuiviOptions() {
  const [currentUser, setCurrentUser] = useState(null);
  const [filter, setFilter] = useState("all");
  const queryClient = useQueryClient();

  const updateLotMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.LotLMNP.update(id, data),
    onSuccess: () => {
      queryClient.refetchQueries({ queryKey: ['lots_suivi'] });
      queryClient.refetchQueries({ queryKey: ['toutes_mes_options'] });
      toast.success('Statut mis à jour avec succès');
    },
    onError: (error) => {
      console.error('Erreur lors de la mise à jour:', error);
      toast.error('Erreur lors de la mise à jour du statut');
    },
  });

  useEffect(() => {
    base44.auth.me().then(setCurrentUser);
  }, []);

  const { data: toutesOptions = [], refetch: refetchOptions } = useQuery({
    queryKey: ['toutes_mes_options'],
    queryFn: () => base44.entities.OptionLot.filter({ partenaire_id: currentUser?.partenaire_id }),
    enabled: !!currentUser?.partenaire_id,
    staleTime: 0,
    cacheTime: 0,
  });

  const { data: lots = [], refetch: refetchLots } = useQuery({
    queryKey: ['lots_suivi'],
    queryFn: () => base44.entities.LotLMNP.list(),
    staleTime: 0,
    cacheTime: 0,
  });

  useEffect(() => {
    const checkExpiredOptions = async () => {
      if (!currentUser?.partenaire_id) return;

      try {
        const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
        const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

        const response = await fetch(
          `${supabaseUrl}/functions/v1/expire-options-cron`,
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${supabaseKey}`,
              'Content-Type': 'application/json',
            },
          }
        );

        if (response.ok) {
          const result = await response.json();
          console.log('Options expirées vérifiées:', result);
        }
      } catch (error) {
        console.error('Erreur lors de la vérification des options expirées:', error);
      }
    };

    if (currentUser?.partenaire_id) {
      checkExpiredOptions();
      refetchOptions();
      refetchLots();
    }
  }, [currentUser?.partenaire_id]);

  // Filtrer les lots par statut
  const filteredLots = filter === "all" 
    ? lots 
    : lots.filter(l => l.statut === filter);

  // Regrouper les LOTS par statut (pas les options)
  // Pour chaque option du partenaire, on récupère le lot correspondant
  const getLotsByStatut = (statut) => {
    // D'abord, on obtient tous les lots avec ce statut
    const lotsAvecStatut = lots.filter(l => l.statut === statut);

    // Filtrer uniquement les options actives (ni annulée, ni convertie)
    const optionsActives = toutesOptions.filter(opt => opt.statut === 'active');

    // Ensuite, on garde seulement ceux qui ont au moins une option active du partenaire
    const lotsPartenaire = lotsAvecStatut
      .filter(lot => {
        // Vérifier si ce lot a au moins une option active du partenaire
        return optionsActives.some(opt => opt.lot_lmnp_id === lot.id);
      })
      .map(lot => {
        // Trouver l'option active la plus récente pour ce lot
        const optionsForLot = optionsActives
          .filter(o => o.lot_lmnp_id === lot.id)
          .sort((a, b) => new Date(b.created_at || b.date_option) - new Date(a.created_at || a.date_option));

        return {
          ...lot,
          option: optionsForLot[0] || null
        };
      });

    return lotsPartenaire;
  };

  const lotsSousOption = getLotsByStatut('sous_option');
  const lotsReserve = getLotsByStatut('reserve');
  const lotsAllotement = getLotsByStatut('allotement');
  const lotsCompromis = getLotsByStatut('compromis');
  const lotsVendu = getLotsByStatut('vendu');

  const getTimeRemaining = (dateFin) => {
    const now = new Date();
    const end = new Date(dateFin);
    const diff = end - now;
    
    if (diff <= 0) return "Expiré";
    
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    if (days > 0) return `${days}j ${hours}h`;
    return `${hours}h`;
  };

  const renderLotCard = (lotWithOption) => {
    const lot = lotWithOption;
    const option = lotWithOption.option;

    const isExpiringSoon = option && option.statut === 'active' && new Date(option.date_expiration) - new Date() < 24 * 60 * 60 * 1000;
    const isMyOption = option && option.user_email === currentUser?.email;

    // Utiliser les informations du lot
    const lotReference = lot.reference || 'N/A';
    const residenceNom = lot.residence_nom || 'N/A';
    const acquereurNom = lot.acquereur_nom || 'Non spécifié';
    const lotStatut = lot.statut || 'inconnu';

    const lotStatusColors = {
      disponible: "bg-green-100 text-green-800",
      sous_option: "bg-blue-100 text-blue-800",
      allotement: "bg-cyan-100 text-cyan-800",
      reserve: "bg-yellow-100 text-yellow-800",
      compromis: "bg-orange-100 text-orange-800",
      vendu: "bg-purple-100 text-purple-800",
    };

    const lotStatusLabels = {
      disponible: "Disponible",
      sous_option: "Sous option",
      allotement: "Allotement",
      reserve: "Réservé",
      compromis: "Compromis",
      vendu: "Vendu",
    };

    return (
      <Card key={lot.id} className="border-none shadow-md">
        <CardContent className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <p className="font-semibold text-[#1E40AF] text-lg">
                  Lot {lotReference}
                </p>
                {option.pose_par === 'admin' && (
                  <Badge className="bg-indigo-100 text-indigo-800 text-xs">
                    Posée par admin
                  </Badge>
                )}
              </div>
              <p className="text-sm text-slate-600 mb-3">{residenceNom}</p>

              {/* Statut du lot en gros */}
              <Badge className={`${lotStatusColors[lotStatut]} text-base px-3 py-1.5 font-semibold`}>
                {lotStatusLabels[lotStatut]}
              </Badge>
            </div>
          </div>

          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-500">Acquéreur:</span>
              <span className="font-medium">{acquereurNom}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Date début:</span>
              <span className="font-medium">
                {option && option.date_option ? new Date(option.date_option).toLocaleDateString('fr-FR') : 'N/A'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Date fin:</span>
              <span className="font-medium">
                {option && option.date_expiration ? new Date(option.date_expiration).toLocaleDateString('fr-FR') : 'N/A'}
              </span>
            </div>
            {option && option.notification_recipient && (
              <div className="pt-2 border-t mt-2">
                <div className="flex items-start gap-2">
                  {option.email_sent ? (
                    <MailCheck className="w-4 h-4 text-green-600 mt-0.5" />
                  ) : (
                    <Mail className="w-4 h-4 text-blue-600 mt-0.5" />
                  )}
                  <div className="flex-1">
                    <p className="text-xs font-medium text-slate-700">Notification email</p>
                    <p className="text-xs text-slate-600">À: {option.notification_recipient}</p>
                    {option.email_scheduled_at && !option.email_sent && (
                      <p className="text-xs text-blue-600 mt-1">
                        Prévu: {new Date(option.email_scheduled_at).toLocaleDateString('fr-FR')} à {new Date(option.email_scheduled_at).toLocaleTimeString('fr-FR', {hour: '2-digit', minute: '2-digit'})}
                      </p>
                    )}
                    {option.email_sent && option.email_sent_at && (
                      <p className="text-xs text-green-600 mt-1">
                        Envoyé: {new Date(option.email_sent_at).toLocaleDateString('fr-FR')} à {new Date(option.email_sent_at).toLocaleTimeString('fr-FR', {hour: '2-digit', minute: '2-digit'})}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}
            {option && option.statut === 'active' && (
              <div className={`p-3 rounded-lg border mt-3 ${isExpiringSoon ? 'bg-red-50 border-red-200' : 'bg-blue-50 border-blue-200'}`}>
                <div className="flex items-center gap-2">
                  <Clock className={`w-4 h-4 ${isExpiringSoon ? 'text-red-600' : 'text-blue-600'}`} />
                  <span className={`font-semibold ${isExpiringSoon ? 'text-red-800' : 'text-blue-800'}`}>
                    {getTimeRemaining(option.date_expiration)} restants
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Actions rapides pour changer le statut */}
          <div className="mt-4 pt-4 border-t border-slate-100">
            <p className="text-xs font-semibold text-slate-600 mb-2">Actions rapides</p>
            <div className="flex gap-2 flex-wrap">
              {lotStatut === 'sous_option' && (
                <Button
                  size="sm"
                  variant="outline"
                  className="text-xs"
                  onClick={() => updateLotMutation.mutate({
                    id: lot.id,
                    data: { statut: 'reserve' }
                  })}
                  disabled={updateLotMutation.isLoading}
                >
                  <ChevronRight className="w-3 h-3 mr-1" />
                  Passer en réservé
                </Button>
              )}
              {lotStatut === 'reserve' && (
                <Button
                  size="sm"
                  variant="outline"
                  className="text-xs"
                  onClick={() => updateLotMutation.mutate({
                    id: lot.id,
                    data: { statut: 'compromis' }
                  })}
                  disabled={updateLotMutation.isLoading}
                >
                  <ChevronRight className="w-3 h-3 mr-1" />
                  Passer en compromis
                </Button>
              )}
              {lotStatut === 'compromis' && (
                <Button
                  size="sm"
                  variant="outline"
                  className="text-xs"
                  onClick={() => updateLotMutation.mutate({
                    id: lot.id,
                    data: { statut: 'vendu' }
                  })}
                  disabled={updateLotMutation.isLoading}
                >
                  <ChevronRight className="w-3 h-3 mr-1" />
                  Passer en vendu
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="p-6 md:p-8 bg-[#F9FAFB] min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-[#1E40AF]">Suivi de mes options</h1>
          <p className="text-slate-500 mt-1">Historique complet de vos options et réservations</p>
        </div>

        {/* Filtre par statut de lot */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <Filter className="w-5 h-5 text-[#F59E0B]" />
              <div className="flex-1">
                <p className="text-sm font-semibold text-slate-700 mb-2">Filtrer par statut du lot</p>
                <Select value={filter} onValueChange={setFilter}>
                  <SelectTrigger className="w-full md:w-64">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white">
                    <SelectItem value="all">Tous les statuts</SelectItem>
                    <SelectItem value="sous_option">Sous option</SelectItem>
                    <SelectItem value="allotement">Allotement</SelectItem>
                    <SelectItem value="reserve">Réservé</SelectItem>
                    <SelectItem value="compromis">Compromis</SelectItem>
                    <SelectItem value="vendu">Vendu</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Statistiques */}
        <div className="grid md:grid-cols-5 gap-6 mb-8">
          <Card className="border-none shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-green-50">
                  <Clock className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">Sous option</p>
                  <p className="text-2xl font-bold text-[#1E40AF]">{lotsSousOption.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-blue-50">
                  <CheckCircle className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">Réservé</p>
                  <p className="text-2xl font-bold text-[#1E40AF]">{lotsReserve.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-purple-50">
                  <AlertCircle className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">Allotement</p>
                  <p className="text-2xl font-bold text-[#1E40AF]">{lotsAllotement.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-orange-50">
                  <CheckCircle className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">Compromis</p>
                  <p className="text-2xl font-bold text-[#1E40AF]">{lotsCompromis.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-amber-50">
                  <ShoppingBag className="w-6 h-6 text-amber-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">Vendu</p>
                  <p className="text-2xl font-bold text-[#1E40AF]">{lotsVendu.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs par statut de lot */}
        <Tabs defaultValue="sous_option" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="sous_option">Sous option ({lotsSousOption.length})</TabsTrigger>
            <TabsTrigger value="reserve">Réservé ({lotsReserve.length})</TabsTrigger>
            <TabsTrigger value="allotement">Allotement ({lotsAllotement.length})</TabsTrigger>
            <TabsTrigger value="compromis">Compromis ({lotsCompromis.length})</TabsTrigger>
            <TabsTrigger value="vendu">Vendu ({lotsVendu.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="sous_option" className="mt-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {lotsSousOption.length === 0 ? (
                <p className="text-slate-400 col-span-full text-center py-12">Aucun lot sous option</p>
              ) : (
                lotsSousOption.map(renderLotCard)
              )}
            </div>
          </TabsContent>

          <TabsContent value="reserve" className="mt-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {lotsReserve.length === 0 ? (
                <p className="text-slate-400 col-span-full text-center py-12">Aucun lot réservé</p>
              ) : (
                lotsReserve.map(renderLotCard)
              )}
            </div>
          </TabsContent>

          <TabsContent value="allotement" className="mt-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {lotsAllotement.length === 0 ? (
                <p className="text-slate-400 col-span-full text-center py-12">Aucun lot en allotement</p>
              ) : (
                lotsAllotement.map(renderLotCard)
              )}
            </div>
          </TabsContent>

          <TabsContent value="compromis" className="mt-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {lotsCompromis.length === 0 ? (
                <p className="text-slate-400 col-span-full text-center py-12">Aucun lot en compromis</p>
              ) : (
                lotsCompromis.map(renderLotCard)
              )}
            </div>
          </TabsContent>

          <TabsContent value="vendu" className="mt-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {lotsVendu.length === 0 ? (
                <p className="text-slate-400 col-span-full text-center py-12">Aucun lot vendu</p>
              ) : (
                lotsVendu.map(renderLotCard)
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}