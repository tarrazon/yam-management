import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Search, Filter, Download, Grid3x3, List } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { motion, AnimatePresence } from "framer-motion";
import LotLMNPCard from "../components/lots-lmnp/LotLMNPCard";
import LotLMNPListItem from "../components/lots-lmnp/LotLMNPListItem";
import LotLMNPDetail from "../components/lots-lmnp/LotLMNPDetail";
import PoserOptionPartenaireDialog from "../components/lots-lmnp/PoserOptionPartenaireDialog";
import { viewsTracking } from "@/api/viewsTracking";

export default function LotsPartenaire() {
  const [currentUser, setCurrentUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [viewMode, setViewMode] = useState("list");
  const [viewingLot, setViewingLot] = useState(null);
  const [lotForOption, setLotForOption] = useState(null);
  const [filters, setFilters] = useState({
    fiscalite: "all",
    region: "all",
    ville: "all",
    type: "all",
    prixMin: 0,
    prixMax: 1000000,
    rentabiliteMin: 0,
    residence_id: "all",
  });
  const [showFilters, setShowFilters] = useState(false);

  const queryClient = useQueryClient();

  const { data: lots = [], refetch: refetchLots } = useQuery({
    queryKey: ['lots_disponibles'],
    queryFn: () => base44.entities.LotLMNP.list(),
    staleTime: 0,
    cacheTime: 0,
  });

  const { data: residences = [] } = useQuery({
    queryKey: ['residences'],
    queryFn: () => base44.entities.ResidenceGestion.list(),
  });

  const { data: partenaire } = useQuery({
    queryKey: ['mon_partenaire', currentUser?.partenaire_id],
    queryFn: () => base44.entities.Partenaire.filter({ id: currentUser?.partenaire_id }).then(res => res[0]),
    enabled: !!currentUser?.partenaire_id,
  });

  const { data: mesOptions = [], refetch: refetchOptions } = useQuery({
    queryKey: ['mes_options_partenaire'],
    queryFn: () => base44.entities.OptionLot.filter({ partenaire_id: currentUser?.partenaire_id }),
    enabled: !!currentUser?.partenaire_id,
    staleTime: 0,
    cacheTime: 0,
  });

  const { data: allOptions = [], refetch: refetchAllOptions } = useQuery({
    queryKey: ['all_options_partenaire'],
    queryFn: () => base44.entities.OptionLot.list(),
    staleTime: 0,
    cacheTime: 0,
  });

  const { data: mesAcquereurs = [] } = useQuery({
    queryKey: ['mes_acquereurs_select'],
    queryFn: () => base44.entities.Acquereur.filter({ partenaire_id: currentUser?.partenaire_id }),
    enabled: !!currentUser?.partenaire_id,
  });

  useEffect(() => {
    base44.auth.me().then(setCurrentUser);

    // Vérifier s'il y a un filtre de résidence dans l'URL
    const urlParams = new URLSearchParams(window.location.search);
    const residenceId = urlParams.get('residence_id');
    if (residenceId) {
      setFilters(prev => ({ ...prev, residence_id: residenceId }));
    }
  }, []);

  useEffect(() => {
    if (refetchLots && refetchAllOptions) {
      refetchLots();
      refetchAllOptions();
    }
  }, [currentUser]);

  const createOptionMutation = useMutation({
    mutationFn: (data) => base44.entities.OptionLot.create(data),
    onSuccess: () => {
      // Invalider TOUS les caches liés aux options et lots
      queryClient.invalidateQueries({ queryKey: ['mes_options_partenaire'] });
      queryClient.invalidateQueries({ queryKey: ['lots_disponibles'] });
      queryClient.invalidateQueries({ queryKey: ['all_options_partenaire'] });
      queryClient.invalidateQueries({ queryKey: ['lots_lmnp'] });
      queryClient.invalidateQueries({ queryKey: ['all_options'] });
      queryClient.invalidateQueries({ queryKey: ['toutes_mes_options'] });
      queryClient.invalidateQueries({ queryKey: ['lots_suivi'] });
    },
  });

  const updateLotMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.LotLMNP.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['lots_disponibles'] });
      queryClient.invalidateQueries({ queryKey: ['lots_lmnp'] });
      queryClient.invalidateQueries({ queryKey: ['lots_suivi'] });
    },
  });

  const handlePoserOption = async (lot, acquereurId) => {
    try {
      // Ne pas vérifier côté client - la contrainte unique en base de données gérera les doublons
      // Vérifier uniquement le nombre d'options actives du partenaire (pas le statut du lot)
      const optionsActives = mesOptions.filter(o => o.statut === 'active').length;
      const optionsMax = partenaire?.options_max || 3;

      if (optionsActives >= optionsMax) {
        alert(`Vous avez atteint votre limite de ${optionsMax} options simultanées.`);
        setLotForOption(null);
        return;
      }

      const dureeJours = partenaire?.duree_option_jours || 5;
      const dateDebut = new Date();
      const dateFin = new Date(dateDebut.getTime() + dureeJours * 24 * 60 * 60 * 1000);

      const acquereur = mesAcquereurs.find(a => a.id === acquereurId);

      const optionData = {
        lot_lmnp_id: lot.id,
        partenaire_id: currentUser.partenaire_id,
        partenaire_nom: partenaire?.nom || '',
        acquereur_id: acquereurId,
        acquereur_nom: acquereur ? `${acquereur.prenom} ${acquereur.nom}` : '',
        lot_reference: lot.reference || '',
        residence_nom: lot.residence_nom || '',
        date_option: dateDebut.toISOString().split('T')[0],
        date_expiration: dateFin.toISOString().split('T')[0],
        statut: 'active',
        pose_par: 'partenaire',
        user_email: currentUser?.email || '',
      };

      // Créer l'option - le trigger sync_lot_statut_on_option_change gérera automatiquement le statut du lot
      const createdOption = await createOptionMutation.mutateAsync(optionData);

      try {
        const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
        const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

        await fetch(`${supabaseUrl}/functions/v1/send-option-notification`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${supabaseAnonKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            partenaire_id: currentUser.partenaire_id,
            partenaire_nom: partenaire?.nom || '',
            partenaire_prenom: partenaire?.prenom || '',
            lot_id: lot.id,
            lot_numero: lot.reference || '',
            residence_nom: lot.residence_nom || '',
            acquereur_nom: acquereur?.nom || '',
            acquereur_prenom: acquereur?.prenom || '',
            date_debut: dateDebut.toISOString(),
            date_fin: dateFin.toISOString(),
            option_id: createdOption?.id || null,
          }),
        });
      } catch (error) {
        console.error('Erreur lors de l\'envoi des notifications:', error);
      }

      // Attendre un peu pour que le trigger DB se propage
      await new Promise(resolve => setTimeout(resolve, 300));

      // Invalider tous les caches et forcer un refetch
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['lots_disponibles'], refetchType: 'active' }),
        queryClient.invalidateQueries({ queryKey: ['mes_options_partenaire'], refetchType: 'active' }),
        queryClient.invalidateQueries({ queryKey: ['all_options_partenaire'], refetchType: 'active' }),
        queryClient.invalidateQueries({ queryKey: ['lots_lmnp'], refetchType: 'active' }),
      ]);

      // Attendre que les refetch soient terminés
      await new Promise(resolve => setTimeout(resolve, 200));

      setLotForOption(null);
      alert('Option posée avec succès ! Le lot est maintenant sous option.');
    } catch (error) {
      console.error('Erreur lors de la prise d\'option:', error);
      const errorMessage = error?.message || error?.toString() || 'Erreur inconnue';
      if (errorMessage.includes('unique') || errorMessage.includes('duplicate')) {
        alert('Une option est déjà active sur ce lot. Veuillez rafraîchir la page.');
      } else {
        alert(`Erreur lors de la prise d'option: ${errorMessage}. Veuillez réessayer.`);
      }
      setLotForOption(null);
    }
  };

  // Filtrage
  // On se base uniquement sur le statut du lot, pas sur les options
  // Le trigger de la base de données synchronise automatiquement le statut
  const filteredLots = lots
    .filter(l => l.statut === 'disponible')
    .filter(l => !searchTerm || l.reference?.toLowerCase().includes(searchTerm.toLowerCase()) || l.residence_nom?.toLowerCase().includes(searchTerm.toLowerCase()))
    .filter(l => filters.fiscalite === "all" || l.statut_fiscal === filters.fiscalite)
    .filter(l => {
      if (filters.region === "all") return true;
      const residence = residences.find(r => r.id === l.residence_id);
      return residence?.region?.toLowerCase() === filters.region.toLowerCase();
    })
    .filter(l => {
      if (filters.ville === "all") return true;
      const residence = residences.find(r => r.id === l.residence_id);
      return residence?.ville?.toLowerCase() === filters.ville.toLowerCase();
    })
    .filter(l => filters.type === "all" || l.type_residence === filters.type)
    .filter(l => (l.prix_fai || 0) >= filters.prixMin && (l.prix_fai || 0) <= filters.prixMax)
    .filter(l => (l.rentabilite || 0) >= filters.rentabiliteMin)
    .filter(l => filters.residence_id === "all" || l.residence_id === filters.residence_id);

  // Export Excel avec commission
  const exportToExcel = () => {
    const tauxRetrocession = partenaire?.taux_retrocession || 0;
    const dataToExport = filteredLots.map(lot => {
      const residence = residences.find(r => r.id === lot.residence_id);
      const prixNetVendeur = Number(lot.prix_net_vendeur) || 0;
      const commission = prixNetVendeur > 0 ? (prixNetVendeur * tauxRetrocession / 100) : 0;
      return {
        "Référence": lot.reference || "",
        "Résidence": lot.residence_nom || "",
        "Ville": residence?.ville || "",
        "Type": lot.type_residence || "",
        "Typologie": lot.typologie || "",
        "Surface (m²)": lot.surface || "",
        "Prix FAI (€)": lot.prix_fai || "",
        "Honoraires (€)": lot.honoraires || "",
        "Ma Commission (€)": Math.round(commission),
        "Loyer mensuel (€)": lot.loyer_mensuel || "",
        "Rentabilité (%)": lot.rentabilite || "",
        "Statut": lot.statut || "",
      };
    });

    const headers = Object.keys(dataToExport[0] || {});
    const csvContent = [
      headers.join(';'),
      ...dataToExport.map(row => headers.map(h => row[h]).join(';'))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `lots_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Récupérer les villes uniques
  const villes = [...new Set(residences.map(r => r.ville).filter(Boolean))];
  const regions = [...new Set(residences.map(r => r.region).filter(Boolean))].sort();

  const getResidenceForLot = (lotResidenceId) => {
    return residences.find(r => r.id === lotResidenceId);
  };

  const handleView = async (lot) => {
    setViewingLot(lot);
    // Tracker la vue du lot
    if (currentUser) {
      await viewsTracking.trackView('lot', lot.id, lot.reference, currentUser);
    }
  };

  // Enrichir les lots avec la commission
  const lotsWithCommission = filteredLots.map(lot => {
    const tauxRetrocession = partenaire?.taux_retrocession || 0;
    const prixNetVendeur = Number(lot.prix_net_vendeur) || 0;
    const commission = prixNetVendeur > 0 ? (prixNetVendeur * tauxRetrocession / 100) : 0;
    return { ...lot, commission_calculee: commission };
  });

  return (
    <div className="p-6 md:p-8 bg-[#F9FAFB] min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-[#1E40AF]">Lots disponibles</h1>
            <p className="text-slate-500 mt-1">
              {filteredLots.length} lots trouvés · Taux de rétrocession: {partenaire?.taux_retrocession || 0}%
            </p>
          </div>
          <Button onClick={exportToExcel} variant="outline" className="border-[#1E40AF] text-[#1E40AF]">
            <Download className="w-4 h-4 mr-2" />
            Export Excel
          </Button>
        </div>

        {/* Barre de recherche et filtres */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex gap-4 mb-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                <Input
                  placeholder="Rechercher par référence ou résidence..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  variant={viewMode === "grid" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setViewMode("grid")}
                  className={viewMode === "grid" ? "bg-[#1E40AF]" : ""}
                >
                  <Grid3x3 className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setViewMode("list")}
                  className={viewMode === "list" ? "bg-[#1E40AF]" : ""}
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
              <Button
                onClick={() => setShowFilters(!showFilters)}
                variant={showFilters ? "default" : "outline"}
                className={showFilters ? "bg-[#1E40AF]" : ""}
              >
                <Filter className="w-4 h-4 mr-2" />
                Filtres
              </Button>
            </div>

            {showFilters && (
              <div className="grid md:grid-cols-3 gap-4 pt-4 border-t">
                <div className="space-y-2">
                  <Label>Résidence</Label>
                  <Select value={filters.residence_id} onValueChange={(v) => setFilters({...filters, residence_id: v})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes les résidences</SelectItem>
                      {residences.map(r => (
                        <SelectItem key={r.id} value={r.id}>{r.nom}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Type de résidence</Label>
                  <Select value={filters.type} onValueChange={(v) => setFilters({...filters, type: v})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous types</SelectItem>
                      <SelectItem value="etudiante">Étudiante</SelectItem>
                      <SelectItem value="senior">Senior</SelectItem>
                      <SelectItem value="ehpad">EHPAD</SelectItem>
                      <SelectItem value="tourisme">Tourisme</SelectItem>
                      <SelectItem value="affaires">Affaires</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Région</Label>
                  <Select value={filters.region} onValueChange={(v) => setFilters({...filters, region: v})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes les régions</SelectItem>
                      {regions.map(r => (
                        <SelectItem key={r} value={r}>{r}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Ville</Label>
                  <Select value={filters.ville} onValueChange={(v) => setFilters({...filters, ville: v})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes les villes</SelectItem>
                      {villes.map(v => (
                        <SelectItem key={v} value={v}>{v}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Prix: {filters.prixMin.toLocaleString('fr-FR')} € - {filters.prixMax.toLocaleString('fr-FR')} €</Label>
                  <Slider
                    value={[filters.prixMin, filters.prixMax]}
                    onValueChange={([min, max]) => setFilters({...filters, prixMin: min, prixMax: max})}
                    min={0}
                    max={1000000}
                    step={10000}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Rentabilité minimum: {filters.rentabiliteMin.toFixed(1)}%</Label>
                  <Slider
                    value={[filters.rentabiliteMin]}
                    onValueChange={([v]) => setFilters({...filters, rentabiliteMin: v})}
                    min={0}
                    max={15}
                    step={0.5}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Statut fiscal</Label>
                  <Select value={filters.fiscalite} onValueChange={(v) => setFilters({...filters, fiscalite: v})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous</SelectItem>
                      <SelectItem value="lmnp">LMNP</SelectItem>
                      <SelectItem value="lmp">LMP</SelectItem>
                      <SelectItem value="sci">SCI</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="md:col-span-3 flex justify-end">
                  <Button
                    variant="outline"
                    onClick={() => setFilters({
                      fiscalite: "all",
                      region: "all",
                      ville: "all",
                      type: "all",
                      prixMin: 0,
                      prixMax: 1000000,
                      rentabiliteMin: 0,
                      residence_id: "all",
                    })}
                  >
                    Réinitialiser les filtres
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Liste des lots avec miniatures */}
        {lotsWithCommission.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-slate-400 text-lg">Aucun lot trouvé avec ces critères</p>
          </div>
        ) : viewMode === "grid" ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence>
              {lotsWithCommission.map((lot) => {
                // Tous les lots disponibles peuvent avoir une option posée
                const canPoserOption = lot.statut === 'disponible';
                return (
                  <LotLMNPCard
                    key={lot.id}
                    lot={lot}
                    onEdit={null}
                    onView={handleView}
                    onPoserOption={canPoserOption ? () => {
                      setLotForOption(lot);
                    } : null}
                    showCommission={true}
                    commission={lot.commission_calculee}
                    hidePartenaireAcquereur={true}
                    partenaires={partenaire ? [partenaire] : []}
                  />
                );
              })}
            </AnimatePresence>
          </div>
        ) : (
          <div className="space-y-3">
            <AnimatePresence>
              {lotsWithCommission.map((lot) => {
                const canPoserOption = lot.statut === 'disponible';
                return (
                  <LotLMNPListItem
                    key={lot.id}
                    lot={lot}
                    onEdit={null}
                    onView={handleView}
                    onPoserOption={canPoserOption ? () => {
                      setLotForOption(lot);
                    } : null}
                    showCommission={true}
                    commission={lot.commission_calculee}
                    hidePartenaireAcquereur={true}
                    partenaires={partenaire ? [partenaire] : []}
                    showExtendedView={false}
                  />
                );
              })}
            </AnimatePresence>
          </div>
        )}

        {/* Détail du lot */}
        <AnimatePresence>
          {viewingLot && (
            <LotLMNPDetail
              lot={viewingLot}
              residence={getResidenceForLot(viewingLot.residence_id)}
              onClose={() => setViewingLot(null)}
              onEdit={null}
              partenaire={partenaire}
            />
          )}
        </AnimatePresence>

        {/* Dialog pour poser une option */}
        {lotForOption && currentUser && (
          <PoserOptionPartenaireDialog
            lot={lotForOption}
            mesAcquereurs={mesAcquereurs}
            optionsActives={mesOptions.filter(o => o.statut === 'active').length}
            optionsMax={partenaire?.options_max || 3}
            dureeJours={partenaire?.duree_option_jours || 5}
            onSubmit={handlePoserOption}
            onCancel={() => {
              setLotForOption(null);
            }}
          />
        )}
      </div>
    </div>
  );
}